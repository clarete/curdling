from setuptools import setup, find_packages

setup(
    name="fake-pkg",
    version='0.0.0',
    description="just something fake",
    long_description='not worth it',
    author='Lincoln Clarete',
    author_email='lincoln@clarete.li',
    url='https://github.com/clarete/curdling',
    packages=find_packages(exclude=['*tests*']),
    install_requires=['gherkin==0.1.0'],
    include_package_data=True,
    classifiers=['Programming Language :: Python'],
)
