from setuptools import setup

setup(
    name="test-dependency-failure",
    version='0.1.0',
    install_requires=['broken-package==0.0.1'],
    description="This package depends on a broken package",
    long_description="""\
Check test `test_failing_gracefuly_after_dependency_failure()`

This package will be requested, but its dependency is broken, so we'll write a
test to ensure that a package will be marked as failed when one or more of its
dependencies can't be installed.
"""
)
