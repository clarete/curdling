# Gherkin parser

> Gherkin is the language that Cucumber understands.

*-- Says the [Gherkin wiki page](https://github.com/cucumber/cucumber/wiki/Gherkin)*

This project aims to write a stable, reasonably fast and modular library to
parse Gherkin files.
