from __future__ import print_function
from gherkin import Lexer
import os


def main(fname):
    if not os.path.exists(fname):
        return 
    with open(fname) as f:
        print(Lexer().scan(f.read()))


if __name__ == '__main__':
    import sys
    len(sys.argv) == 2 and main(sys.argv[1])
