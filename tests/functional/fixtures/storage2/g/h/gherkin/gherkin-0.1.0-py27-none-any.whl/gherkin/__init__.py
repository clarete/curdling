from __future__ import unicode_literals
from functools import wraps
import re


class matcher(object):
    """Decorator for creating new matchers for the lexer analyzer.

    This decorator compiles an RE out of the pattern (and flags) received and
    wrap the actual scan operation with a function that executes the compiled
    RE, calling the actual function if the matching is successful.
    """
    def __init__(self, pattern, flags=0):
        # Yay, this line will get called only once per pattern since the
        # matcher (and thus the assigner functions) are called when python is
        # still reading the decorated methods from the `Lexer` class.
        self.regex = re.compile(pattern, flags=flags)

    def __call__(self, func):

        # Saving the local attribute inside of the closure's namespace so we
        # can use it inside of the decorator
        regex = self.regex

        @wraps(func)
        def decorator(self, chunk):
            # The actuall matcher won't get called unless the pattern can be
            # matched agains the piece of text received from the lexer.
            found = regex.findall(chunk)
            if found:
                return func(self, found[0])

        return decorator


class Lexer(object):

    def __init__(self):
        self.lineno = 1

    def scan(self, data):
        i = 0
        tokens = []

        while i < len(data):
            chunk = data[i:]

            # Expressions to find out wtf is that chunk
            handlers = [
                self.cookie_monster,
                self.scan_colon,
                self.scan_conf,
                self.scan_comment,
                self.scan_examples,
                self.scan_tags,
                self.scan_multiline_strings,
                self.scan_text,
            ]

            for handler in handlers:
                found = handler(chunk)

                if found:
                    kind, token, size = found

                    # The `scan_indent` handler might not return tokens, but we
                    # still need to skip the newline character found inside of
                    # the same indent level
                    if kind:
                        tokens.append((kind, self.lineno, token))

                    i += size
                    break

        return tokens

    @matcher(r'\A(\n+)')
    def cookie_monster(self, found):
        found_size = len(found)
        self.lineno += found_size
        return ('', found, found_size)

    @matcher(r'\A\:')
    def scan_colon(self, found):
        return (':', '', len(found))

    @matcher(r'\A(\#\s*)(language|encoding)(: )([^\n]+)')
    def scan_conf(self, found):
        return ('metadata', (found[1], found[3]), sum(map(len, found)))

    @matcher(r'\A(\s*\#\s*)([^\n]+)')
    def scan_comment(self, found):
        return ('comment', found[1], sum(map(len, found)))

    @matcher(r'\A(\s+\|)([^\n]+)(\|)', re.M)
    def scan_examples(self, found):
        return ('row',
                tuple(f.strip() for f in found[1].split('|')),
                sum(map(len, found)))

    @matcher(r'\A( *@)([^\s]+)( *)')
    def scan_tags(self, found):
        return ('tag', found[1], sum(map(len, found)))

    @matcher(r'\A(\s*""")([^"""]+)')
    def scan_multiline_strings(self, found):
        lines = (f.strip() for f in found[1].splitlines() if f.strip())
        return ('text', '\n'.join(lines), sum(map(len, found))+3)

    @matcher(r'\A([^\n\#\:]+)')
    def scan_text(self, found):
        # Corner case? When there's a comment in the same line we have text we
        # need to strip the text
        return ('text', found.strip(), len(found))
